import random
import re
import streamlit as st
import speech_recognition as sr
import requests

# List of questions
questions = [
    "Introduce yourself.",
    "Describe your favorite childhood memory.",
    "Discuss a recent news article that caught your attention."
]

def capitalize_first_word(sentence):
    # Capitalize the first letter of the first word
    return sentence.capitalize()

def capitalize_i_alone(sentence):
    # Capitalize "I" when used alone in a sentence
    return re.sub(r'\bi\b', 'I', sentence)

def check_grammar(text):
    # LanguageTool API endpoint
    api_url = 'https://languagetool.org/api/v2/check'

    # Parameters for the API request
    params = {
        'text': text,
        'language': 'en-US'
    }

    # Send POST request to LanguageTool API
    response = requests.post(api_url, data=params)

    # Parse response
    if response.ok:
        data = response.json()
        matches = data.get('matches', [])
        num_errors = len(matches)
        
        # Calculate score based on number of errors
        score = max(0, 100 - num_errors * 10)  # Deduct 10 points for each error, maximum score is 100

        if matches:
            st.write("Grammar Errors:")
            for match in matches:
                error_message = match['message']
                error_message = re.sub(r'\[[^\]]*\]', '', error_message)  # Remove identifier and suggestion
                st.write(error_message + f" (Index {match['offset']})")  # Print "Index" instead of "Line"

            st.write(f"\nGrammar Score: {score}/100")
        else:
            st.write("No grammar errors found.")
            st.write(f"\nGrammar Score: 100/100")
    else:
        st.write("Failed to connect to LanguageTool API.")

def speech_to_text():
    # Initialize recognizer
    r = sr.Recognizer()

    # Flag to control listening
    listening = False

    # Streamlit UI
    st.title("Speech to Text and Grammar Checker")
    st.write("Press the button below to start listening and answer a random question.")

    if st.button("Start Listening"):
        if not listening:
            # Randomly select a question
            question = random.choice(questions)
            st.write("Question:", question)

            # Flag to indicate listening
            listening = True

            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source)
                st.write("Listening...")

                try:
                    audio = r.listen(source, timeout=5)  # Timeout after 5 seconds of silence
                    st.write("Processing...")

                    # Recognize speech
                    user_input = r.recognize_google(audio)
                    
                    # Capitalize the first letter of the first word
                    user_input = capitalize_first_word(user_input)
                    
                    # Capitalize "I" when used alone
                    user_input = capitalize_i_alone(user_input)

                    st.write("Speech Recognized!")
                    st.write("You said:", user_input)

                    # Check grammar of the user input
                    check_grammar(user_input)

                except sr.UnknownValueError:
                    st.write("Could not understand audio")
                except sr.RequestError as e:
                    st.write("Error:", str(e))

            # Set listening flag to False
            listening = False

if __name__ == "__main__":
    speech_to_text()
