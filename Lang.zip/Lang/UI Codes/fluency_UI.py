import streamlit as st
import speech_recognition as sr
import time

def assess_fluency(transcript, pause_threshold=1.0):
    # Remove punctuation from the transcript
    transcript = ''.join(char for char in transcript if char.isalnum() or char.isspace())
    
    # Split the transcript into words
    words = transcript.split()
    
    # Count the total number of words
    word_count = len(words)
    
    # Define a list of filler words
    fillers = ['um', 'uh', 'uhh', 'umm', 'like', 'you know', 'so']
    
    # Count the number of filler words
    filler_count = sum(word.lower() in fillers for word in words)
    
    # Count the number of pauses
    pause_count = 0
    is_speaking = False
    for word in words:
        if word.lower() in fillers:
            filler_count += 1
        else:
            is_speaking = True
        
        if not is_speaking:
            pause_count += 1
        is_speaking = False

    fluency_percentage = (1 - (pause_count + filler_count) / word_count) * 100

    return {
        'word_count': word_count,
        'filler_count': filler_count,
        'pause_count': pause_count,
        'fluency_percentage': fluency_percentage
    }

def calculate_speech_rate(audio_duration, word_count):
    # Calculate speech rate in words per minute
    speech_rate = word_count / (audio_duration / 60)
    return speech_rate

def print_analysis(analysis, transcript, audio_duration):
    st.write("Speech Analysis:")
    st.write(f"Transcribed Text: {transcript}")
    st.write(f"Word Count: {analysis['word_count']}")
    st.write(f"Filler Count: {analysis['filler_count']}")
    st.write(f"Pause Count: {analysis['pause_count']}")
    st.write(f"Fluency Percentage: {analysis['fluency_percentage']:.2f}%")
    st.write(f"Speech Rate (words per minute): {calculate_speech_rate(audio_duration, analysis['word_count']):.2f}")
    st.write(f"Audio Duration: {audio_duration:.2f} seconds")

def main():
    st.write("Welcome to the Speech Fluency Assessment Tool!")
    
    # Initialize recognizer and microphone
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    # Record audio from microphone
    st.write("Recording...")
    with microphone as source:
        recognizer.adjust_for_ambient_noise(source)
        start_time = time.time()
        audio = recognizer.listen(source, timeout=10)
        end_time = time.time()
    st.write("Recording finished.")

    # Get the duration of the audio recording
    audio_duration = end_time - start_time

    # Transcribe speech from recorded audio
    try:
        transcript = recognizer.recognize_google(audio)
        analysis = assess_fluency(transcript)
        print_analysis(analysis, transcript, audio_duration)
    except sr.UnknownValueError:
        st.write("Sorry, I could not understand the audio.")
    except sr.RequestError as e:
        st.write(f"Could not request results from Google Speech Recognition service; {e}")

if __name__ == "__main__":
    main()
