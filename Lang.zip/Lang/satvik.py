from gtts import gTTS
import os
import csv
import time
import difflib
from colorama import Fore
import random
import sounddevice as sd
import soundfile as sf

def generate_text():
    sentences = [
        'This is a sample sentence.',
        'Another example sentence.',
        'Yet another random line.',
        'Python is a versatile programming language.',
        'Machine learning is a fascinating field.',
        'Coding is both an art and a science.',
        'Web development involves creating dynamic websites.',
        'Data science involves analyzing and interpreting complex data sets.',
        'Artificial Intelligence is transforming various industries.',
        'Cybersecurity is crucial for protecting digital assets.',
        'The Internet of Things (IoT) connects devices for smart applications.',
        'Cloud computing provides scalable and flexible computing resources.',
        'Open source software encourages collaboration and innovation.',
        'Mobile app development is in high demand.',
        'Blockchain technology ensures secure and transparent transactions.',
        'Virtual reality creates immersive digital experiences.',
        'The future of technology is exciting and unpredictable.',
        'Learning new skills is a lifelong journey.',
        'Books are a great source of knowledge and inspiration.',
        'Traveling broadens the mind and opens new perspectives.',
        # ... add more sentences as needed
    ]

    num_repetitions = max(1, 100 // len(sentences))
    generated_text = sentences * num_repetitions
    random.shuffle(generated_text)

    return generated_text

def write_to_csv_file(record_list):
    with open("listening_record.csv", 'a', newline='') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow(record_list)

def calculate_similarity_ratio(original, user_input):
    original = original.lower()
    user_input = user_input.lower()

    original = ''.join(char for char in original if char.isalnum() or char.isspace())
    user_input = ''.join(char for char in user_input if char.isalnum() or char.isspace())

    return difflib.SequenceMatcher(None, original, user_input).ratio()

def play_audio(filename):
    data, fs = sf.read(filename, dtype='float32')
    sd.play(data, fs)
    sd.wait()

def test_listening_skill():
    print(Fore.RED + "Listen carefully and try to write the same\n")
    list_of_text = generate_text()

    sentences_for_assessment = random.sample(list_of_text, 5)
    cumulative_score = 0

    language = 'en'

    for line in sentences_for_assessment:
        myobj = gTTS(text=line, lang=language, slow=False)
        filename = "readtext_{}.mp3".format(time.time())
        myobj.save(filename)
        play_audio(filename)
        os.remove(filename)

        print(Fore.CYAN + "Type the recently spoken line" + Fore.RESET)
        written_line = input(">>> ")

        similarity_ratio = calculate_similarity_ratio(line, written_line)
        correctness = (similarity_ratio * 100)
        correctness = round(correctness, 2)

        print(Fore.YELLOW + "Correctness Rating: {0:.2f}%".format(correctness) + Fore.RESET)
        cumulative_score += correctness

        write_to_csv_file([correctness])
        print()

    average_score = cumulative_score / len(sentences_for_assessment)

    print(Fore.YELLOW + "Results stored successfully" + Fore.RESET)
    print(Fore.LIGHTCYAN_EX + "Cumulative Score: {0:.2f}%".format(average_score) + Fore.RESET)

    if average_score >= 95:
        print(Fore.GREEN + "Congratulations! You have good listening skills." + Fore.RESET)
    else:
        print(Fore.RED + "You need to work on improving your listening skills." + Fore.RESET)

if __name__ == "__main__":
    test_listening_skill()
