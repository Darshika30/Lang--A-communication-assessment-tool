# main.py

import subprocess
import sys
import os

def run_listening_skill():
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "satvik.py")
    print("Listening Assessment 1:")
    subprocess.run([sys.executable, script_path])
    print("===================================")

def run_listening_skill_next():
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "satvik2.py")
    print("Listening Assessment 2:")
    subprocess.run([sys.executable, script_path])
    print("===================================")

if __name__ == "__main__":
    run_listening_skill()
    run_listening_skill_next()
