# main.py

import subprocess
import sys
import os

def run_listening_ass():
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "main.py")
    print("Listening Assessment:")
    subprocess.run([sys.executable, script_path])
    print("===================================")

def run_grammar_ass():
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "main_gram.py")
    print("Grammar Assessment:")
    subprocess.run([sys.executable, script_path])
    print("===================================")

def run_pronounce_ass():
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pronounciation.py")
    print("Pronunciation Assessment:")
    subprocess.run([sys.executable, script_path])
    print("===================================")

def run_fluency_ass():
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fluency.py")
    print("Fluency Assessment:")
    subprocess.run([sys.executable, script_path])
    print("===================================")

def run_last_ass():
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file_fle_)), "last.py")
    print("Presentation Assessment:")
    subprocess.run([sys.executable, script_path])
    print("===================================")



if __name__ == "__main__":
    run_listening_ass()
    run_grammar_ass()
    run_pronounce_ass()
    run_fluency_ass()
    run_last_ass()