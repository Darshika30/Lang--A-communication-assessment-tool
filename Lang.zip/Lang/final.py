import cv2
import dlib
import numpy as np
import time
import pygame
from scipy.spatial import distance as spatial
import subprocess
import sys
import os
from multiprocessing import Process, Event

# Initialize face detector and facial landmarks predictor
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

# Function to check for multiple faces in the frame
def check_multiple_faces(faces):
    return len(faces) > 1

# Initialize pygame for audio
pygame.mixer.init()

# Load the alarm sound
alarm_sound = pygame.mixer.Sound("mixkit-alert-alarm-1005.mp3")

# Function to play the alarm sound
def play_alarm():
    alarm_sound.play()

# Function to compute the cosine similarity
def cosine_similarity(vec1, vec2):
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

# Function to capture and save the user's face for authentication
def capture_user_face():
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Draw a capture button
        cv2.putText(frame, "Press 'c' to Capture", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.imshow('Capture Face for Authentication', frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('c'):
            face_captured = frame.copy()
            cv2.putText(face_captured, "Face Captured!", (30, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.imshow('Captured Face', face_captured)
            cv2.waitKey(2000)  # Display the captured face for 2 seconds
            break

    cap.release()
    cv2.destroyAllWindows()
    return face_captured

# Capture the user's face for authentication
reference_face = capture_user_face()
reference_landmarks = predictor(cv2.cvtColor(reference_face, cv2.COLOR_BGR2GRAY), dlib.rectangle(0, 0, reference_face.shape[1], reference_face.shape[0]))

# Function to run assessment application
def run_assessment():
    script_paths = [
        "main.py",
        "main_gram.py",
        "pronounciation.py",
        "fluency.py",
        "last.py"
    ]

    for script_path in script_paths:
        script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), script_path)
        print(f"Running Assessment: {script_path}")
        subprocess.run([sys.executable, script_path])
        print("===================================")

def proctoring_process(end_event, alarm_count):
    # Initialize webcam capture
    cap = cv2.VideoCapture(0)

    # Initialize variables for tracking time
    start_time_eyes_closed = time.time()
    start_time_mouth_closed = time.time()

    # Flag to track authentication status
    authentication_passed = False
    consistent_recognition_duration = 2  # Duration (in seconds) for consistent recognition

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector(gray)

        # Display the authentication window
        cv2.imshow('Capture Face for Authentication', frame)

        # Authenticate the user's face
        for face in faces:
            landmarks = predictor(gray, face)

            # Calculate the similarity score using cosine similarity
            reference_landmarks_np = np.array([[p.x, p.y] for p in reference_landmarks.parts()])
            current_landmarks_np = np.array([[p.x, p.y] for p in landmarks.parts()])
            reference_landmarks_np = np.array([[p.x, p.y] for p in reference_landmarks.parts()])
            current_landmarks_np = np.array([[p.x, p.y] for p in landmarks.parts()])

            similarity_score = cosine_similarity(reference_landmarks_np.flatten(), current_landmarks_np.flatten())

            if similarity_score > 0.9:  # Adjust this threshold based on your needs
                cv2.rectangle(frame, (face.left(), face.top()), (face.right(), face.bottom()), (0, 255, 0), 2)
                if time.time() - start_time_eyes_closed >= consistent_recognition_duration:
                    authentication_passed = True
                else:
                    authentication_passed = False
            else:
                cv2.rectangle(frame, (face.left(), face.top()), (face.right(), face.bottom()), (0, 0, 255), 2)
                authentication_passed = False

        if check_multiple_faces(faces):
            cv2.putText(frame, "ERROR: Multiple people detected", (30, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            play_alarm()
            alarm_count[0] += 1

        if authentication_passed:
            # Continue with eye and mouth monitoring as in the original code
            pass

        cv2.imshow('Video Proctoring', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        # Check if the end event is set
        if end_event.is_set():
            break

        # Check if three alarms have been triggered
        if alarm_count[0] >= 3:
            print("You were found indulging in unfair means and you are deebared from this Examinantion with UFM. The test is ended")
            break

    cap.release()
    cv2.destroyAllWindows()
    pygame.mixer.quit()  # Quit pygame.mixer to release audio resources

if __name__ == "__main__":
    # Create an event to signal the end of the proctoring process
    proctoring_end_event = Event()

    # Variable to count alarms
    alarm_count = [0]

    # Start the proctoring process
    proctoring_process_instance = Process(target=proctoring_process, args=(proctoring_end_event, alarm_count))
    proctoring_process_instance.start()

    try:
        # Run the assessment application
        run_assessment()
    finally:
        # Set the event to signal the end of the proctoring process
        proctoring_end_event.set()
        # Ensure that the proctoring process has ended
        proctoring_process_instance.join()
