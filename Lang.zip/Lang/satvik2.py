
import time
import difflib
import os
import random
from gtts import gTTS
import platform

def calculate_similarity_ratio(original, user_input):
    original = original.lower()
    user_input = user_input.lower()

    # Remove punctuation for comparison
    original = ''.join(char for char in original if char.isalnum() or char.isspace())
    user_input = ''.join(char for char in user_input if char.isalnum() or char.isspace())

    return difflib.SequenceMatcher(None, original, user_input).ratio()

def read_paragraph(paragraph):
    myobj = gTTS(text=paragraph, lang='en', slow=False)
    filename = "readtext_{}.mp3".format(time.time())
    myobj.save(filename)

    print("Press Enter to start the recitation.")
    input()  # Wait for the user to press Enter

    print("Playing...")
    if platform.system() == "Windows":
        os.startfile(filename)
    else:
        print("Your operating system does not support automatic audio playback. Please open the file manually.")

def ask_mcq_question(question, options, correct_answer):
    print(question)
    for i, option in enumerate(options, 1):
        print(f"{i}. {option}")

    user_input = input("Select the correct option (1-5): ")
    user_input = int(user_input) if user_input.isdigit() else 0

    if 1 <= user_input <= 5:
        selected_answer = options[user_input - 1]
        is_correct = selected_answer == correct_answer
        correctness = "Correct" if is_correct else "Incorrect"
        print(f"Your answer: {selected_answer}. {correctness}\n")  # Added newline after displaying correctness
        return is_correct
    else:
        print("Invalid input. Skipping this question.\n")  # Added newline after skipping question
        return False

def assess_mcq_section():
    paragraph, mcqs = get_paragraphs_and_mcqs()
    read_paragraph(paragraph)

    total_questions = len(mcqs)
    correct_answers = 0

    for q in mcqs:
        is_correct = ask_mcq_question(q['question'], q['options'], q['correct_answer'])
        if is_correct:
            correct_answers += 1

    mcq_score = (correct_answers / total_questions) * 100
    print(f"\nMCQ Section Score: {mcq_score:.2f}%")

    if mcq_score >= 95:
        print("Congratulations! You have successfully completed the assessment.")
    else:
        print("You can improve your performance. Keep practicing!")

def get_paragraphs_and_mcqs():
    paragraphs_and_mcqs = [
        {
            'paragraph': (
                "Artificial Intelligence (AI) is a field of computer science that aims to create intelligent machines. "
                "AI technologies include machine learning, natural language processing, and computer vision. "
                "AI is used in healthcare, finance, and autonomous vehicles to automate tasks and improve efficiency."
            ),
            'mcqs': [
                {
                    'question': 'What is the goal of Artificial Intelligence?',
                    'options': ['To create intelligent machines', 'To develop computer vision', 'To automate tasks', 'To improve efficiency', 'To mimic human-like thinking'],
                    'correct_answer': 'To create intelligent machines'
                },
                {
                    'question': 'Which technologies are part of AI?',
                    'options': ['Machine Learning', 'Natural Language Processing', 'Computer Vision', 'All of the above', 'None of the above'],
                    'correct_answer': 'All of the above'
                },
                {
                    'question': 'In which industries is AI commonly used?',
                    'options': ['Healthcare', 'Finance', 'Autonomous Vehicles', 'All of the above', 'None of the above'],
                    'correct_answer': 'All of the above'
                }
            ]
        },
        {
            'paragraph': (
                "Python is a versatile programming language known for its readability. "
                "It supports procedural, object-oriented, and functional programming. "
                "Python is used for web development, data science, artificial intelligence, and automation."
            ),
            'mcqs': [
                {
                    'question': 'What is Python known for?',
                    'options': ['Readability', 'High performance', 'Complex syntax', 'Limited libraries', 'None of the above'],
                    'correct_answer': 'Readability'
                },
                {
                    'question': 'Which programming paradigms does Python support?',
                    'options': ['Procedural', 'Object-oriented', 'Functional', 'All of the above', 'None of the above'],
                    'correct_answer': 'All of the above'
                },
                {
                    'question': 'In which domains is Python commonly used?',
                    'options': ['Web development', 'Data science', 'Artificial intelligence', 'All of the above', 'None of the above'],
                    'correct_answer': 'All of the above'
                }
            ]
        }
        # Add more paragraphs and corresponding MCQs as needed
    ]

    selected_content = random.choice(paragraphs_and_mcqs)
    return selected_content['paragraph'], selected_content['mcqs']

if __name__ == "__main__":
    assess_mcq_section()
