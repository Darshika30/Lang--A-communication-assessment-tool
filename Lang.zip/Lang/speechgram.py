import random
import re
import speech_recognition as sr
import requests

# List of questions
questions = [
    "Introduce yourself.",
    "Describe your favorite childhood memory.",
    "Discuss a recent news article that caught your attention."
]

def capitalize_first_word(sentence):
    # Capitalize the first letter of the first word
    return sentence.capitalize()

def capitalize_i_alone(sentence):
    # Capitalize "I" when used alone in a sentence
    return re.sub(r'\bi\b', 'I', sentence)

def check_grammar(text):
    # LanguageTool API endpoint
    api_url = 'https://languagetool.org/api/v2/check'

    # Parameters for the API request
    params = {
        'text': text,
        'language': 'en-US'
    }

    # Send POST request to LanguageTool API
    response = requests.post(api_url, data=params)

    # Parse response
    if response.ok:
        data = response.json()
        matches = data.get('matches', [])
        num_errors = len(matches)
        
        # Calculate score based on number of errors
        score = max(0, 100 - num_errors * 10)  # Deduct 10 points for each error, maximum score is 100

        if matches:
            print("Grammar Errors:")
            for match in matches:
                error_message = match['message']
                error_message = re.sub(r'\[[^\]]*\]', '', error_message)  # Remove identifier and suggestion
                print(error_message + f" (Index {match['offset']})")  # Print "Index" instead of "Line"

            print(f"\nGrammar Score: {score}/100")
        else:
            print("No grammar errors found.")
            print(f"\nGrammar Score: 100/100")
    else:
        print("Failed to connect to LanguageTool API.")

def speech_to_text():
    # Initialize recognizer
    r = sr.Recognizer()

    # Flag to control listening
    listening = False

    while True:
        # Wait for user to press Enter
        input("Press Enter to start listening...")

        if not listening:
            # Randomly select a question
            question = random.choice(questions)
            print(question)

            # Flag to indicate listening
            listening = True

            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source)
                print("Listening...")

                try:
                    audio = r.listen(source, timeout=5)  # Timeout after 5 seconds of silence
                    print("Processing...")

                    # Recognize speech
                    user_input = r.recognize_google(audio)
                    
                    # Capitalize the first letter of the first word
                    user_input = capitalize_first_word(user_input)
                    
                    # Capitalize "I" when used alone
                    user_input = capitalize_i_alone(user_input)

                    print("Speech Recognized!")
                    print("You said:", user_input)

                    # Check grammar of the user input
                    check_grammar(user_input)

                except sr.UnknownValueError:
                    print("Could not understand audio")
                except sr.RequestError as e:
                    print("Error:", str(e))

            # Set listening flag to False
            listening = False

            # Exit the loop after one assessment
            break

if __name__ == "__main__":
    speech_to_text()
    