# listening_skill.py

from gtts import gTTS
from playsound import playsound
import time
import difflib
import os

def calculate_similarity_ratio(original, user_input):
    original = original.lower()
    user_input = user_input.lower()

    # Remove punctuation for comparison
    original = ''.join(char for char in original if char.isalnum() or char.isspace())
    user_input = ''.join(char for char in user_input if char.isalnum() or char.isspace())

    return difflib.SequenceMatcher(None, original, user_input).ratio()

def read_text(text):
    myobj = gTTS(text=text, lang='en', slow=False)
    filename = "readtext_{}.mp3".format(time.time())
    myobj.save(filename)

    print("Press Enter to start the recitation.")
    input()  # Wait for the user to press Enter

    print("Playing...")
    playsound(filename)  # Play the audio
    os.remove(filename)

if __name__ == "__main__":
    paragraph = (
        "Artificial Intelligence (AI) is a field of computer science that aims to create intelligent machines. "
        "AI technologies include machine learning, natural language processing, and computer vision. "
        "AI is used in healthcare, finance, and autonomous vehicles to automate tasks and improve efficiency."
    )
    
    read_text(paragraph)
