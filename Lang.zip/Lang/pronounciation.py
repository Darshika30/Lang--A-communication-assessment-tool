import tkinter as tk
from tkinter import ttk
import speech_recognition as sr
import random

def record_audio():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Speak the predetermined sentence...")
        audio = recognizer.listen(source)
    try:
        recognized_text = recognizer.recognize_google(audio)
        input_text.delete('1.0', tk.END)
        input_text.insert(tk.END, recognized_text, 'recognized')
        predetermined_sentence = random.choice(predetermined_sentences)
        comparison_result = compare_text(recognized_text, predetermined_sentence)
        comparison_text.delete('1.0', tk.END)
        comparison_text.insert(tk.END, comparison_result)
    except sr.UnknownValueError:
        input_text.delete('1.0', tk.END)
        input_text.insert(tk.END, "Could not understand audio")
        input_text.tag_config('recognized', foreground='red')
    except sr.RequestError:
        input_text.delete('1.0', tk.END)
        input_text.insert(tk.END, "Could not request results; check your internet connection")
        input_text.tag_config('recognized', foreground='red')

def compare_text(recognized_text, predetermined_sentence):
    comparison_result = ""

    recognized_words = recognized_text.lower().split()
    predetermined_words = predetermined_sentence.lower().split()

    incorrect_penalty = 0.25
    total_penalty = 0
    total_words = max(len(recognized_words), len(predetermined_words))

    for i in range(total_words):
        if i < len(recognized_words) and i < len(predetermined_words):
            if recognized_words[i] != predetermined_words[i]:
                comparison_result += recognized_words[i] + ' (wrong) '
                total_penalty += incorrect_penalty
            else:
                comparison_result += recognized_words[i] + ' '
        elif i < len(recognized_words):
            comparison_result += recognized_words[i] + ' (wrong) '
            total_penalty += incorrect_penalty
        elif i < len(predetermined_words):
            comparison_result += predetermined_words[i] + ' (missing) '
            total_penalty += incorrect_penalty

    comparison_result += "\n"

    # Calculate similarity score
    correct_words = total_words - total_penalty
    similarity_score = (correct_words / total_words) * 100

    comparison_result += f"Similarity score: {similarity_score:.2f}%"

    return comparison_result

root = tk.Tk()
root.title("Pronunciation Checker")

# List of predetermined sentences
predetermined_sentences = [
    "The quick brown fox jumps over the lazy dog",
    "When does class begin tomorrow",
    "The trees here are very tall"
]

# Lavender and white theme
lavender = "#E6E6FA"  # Lavender color
white = "#FFFFFF"  # White color

style = ttk.Style()
style.theme_use("clam")  # Use the 'clam' theme for a modern appearance

root.configure(bg=lavender)

# Label to display the predetermined sentence
sentence_label = ttk.Label(root, text="Predetermined Sentence:", background=lavender)
sentence_label.grid(row=0, column=0)

# Text widget to display predetermined sentence
predetermined_text = tk.Text(root, height=1, width=50, bg=lavender)
predetermined_text.insert(tk.END, random.choice(predetermined_sentences))
predetermined_text.grid(row=0, column=1)

# Label to display the recognized sentence
input_label = ttk.Label(root, text="Recognized Sentence:", background=lavender)
input_label.grid(row=1, column=0)

# Text widget to display recognized text
input_text = tk.Text(root, height=1, width=50, bg=lavender)
input_text.grid(row=1, column=1)

# Label to display the comparison result
comparison_label = ttk.Label(root, text="Comparison Result:", background=lavender)
comparison_label.grid(row=2, column=0)

# Text widget to display comparison result
comparison_text = tk.Text(root, height=5, width=50, bg=lavender)
comparison_text.grid(row=2, column=1, rowspan=2)

# Record button
record_button = ttk.Button(root, text="Record", command=record_audio)
record_button.grid(row=3, column=1, pady=10)

root.mainloop()
