import speech_recognition as sr

class EvaluationModule:
    def __init__(self):
        pass

    def evaluate(self, explanation):
        clarity_score = self._evaluate_clarity(explanation)
        structure_score = self._evaluate_structure(explanation)
        effectiveness_score = self._evaluate_effectiveness(explanation)

        overall_score = (clarity_score + structure_score + effectiveness_score) / 3
        return clarity_score, structure_score, effectiveness_score, overall_score

    def _evaluate_clarity(self, explanation):
        # Heuristic for evaluating clarity
        # Example: Count number of sentences with more than 15 words
        sentences = explanation.split(".")
        unclear_sentences = sum(1 for sentence in sentences if len(sentence.split()) > 15)
        clarity_score = max(100 - unclear_sentences * 10, 0)  # Maximum score of 100, penalize for unclear sentences
        return clarity_score

    def _evaluate_structure(self, explanation):
        # Heuristic for evaluating structure
        # Example: Check if explanation contains subheadings
        if any(subheading in explanation for subheading in ["Introduction", "Method", "Results", "Conclusion"]):
            return 100
        else:
            return 50

    def _evaluate_effectiveness(self, explanation):
        # Heuristic for evaluating effectiveness
        # Example: Check if explanation contains key points or conclusions
        if "key points" in explanation.lower() or "conclusion" in explanation.lower():
            return 100
        else:
            return 50


def display_rules():
    print("Rules and Regulations:")
    print("- Clarity: Your explanation should be clear and easy to understand, avoiding jargon and complex language.")
    print("- Structure: Your explanation should be well-structured, with clear organization and logical flow.")
    print("- Effectiveness: Your explanation should effectively convey key points and conclusions.")
    print("Keep these rules in mind while providing your explanation.")


def main():
    display_rules()
    input("Press Enter when you're ready to start recording your explanation...")

    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Recording...")
        audio = recognizer.listen(source)
        print("Recording finished.")

    try:
        explanation = recognizer.recognize_google(audio)
        print("Your explanation:", explanation)

        evaluation_module = EvaluationModule()
        clarity_score, structure_score, effectiveness_score, overall_score = evaluation_module.evaluate(explanation)

        print("\nEvaluation Summary:")
        print("Clarity Score:", clarity_score)
        print("Structure Score:", structure_score)
        print("Effectiveness Score:", effectiveness_score)
        print("Overall Score:", overall_score)

        print("\nScore Summary:")
        if clarity_score < 70:
            print("Your explanation could be clearer. Try to avoid long sentences and use simpler language.")
        else:
            print("Great job on clarity! Your explanation was clear and easy to understand.")

        if structure_score < 70:
            print("Your explanation could be better organized. Consider adding subheadings or a logical flow.")
        else:
            print("Well done on structure! Your explanation was well-organized and easy to follow.")

        if effectiveness_score < 70:
            print("Your explanation could be more effective. Try to emphasize key points and conclusions.")
        else:
            print("Excellent job on effectiveness! Your explanation effectively conveyed key points.")

    except sr.UnknownValueError:
        print("Sorry, could not understand audio.")
    except sr.RequestError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()