import speech_recognition as sr
import time

def assess_fluency(transcript, pause_threshold=1.0):
    # Remove punctuation from the transcript
    transcript = ''.join(char for char in transcript if char.isalnum() or char.isspace())
    
    # Split the transcript into words
    words = transcript.split()
    
    # Count the total number of words
    word_count = len(words)
    
    # Define a list of filler words
    fillers = ['um', 'uh', 'uhh', 'umm', 'like', 'you know', 'so']
    
    # Count the number of filler wordsy
    filler_count = sum(word.lower() in fillers for word in words)
    
    # Count the number of pauses
    pause_count = 0
    is_speaking = False
    for word in words:
        if word.lower() in fillers:
            filler_count += 1
        else:
            is_speaking = True
        
        if not is_speaking:
            pause_count += 1
        is_speaking = False

    fluency_percentage = (1 - (pause_count + filler_count) / word_count) * 100

    return {
        'word_count': word_count,
        'filler_count': filler_count,
        'pause_count': pause_count,
        'fluency_percentage': fluency_percentage
    }

def calculate_speech_rate(audio_duration, word_count):
    # Calculate speech rate in words per minute
    speech_rate = word_count / (audio_duration / 60)
    return speech_rate

def print_analysis(analysis, transcript, audio_duration):
    print("Speech Analysis:")
    print(f"Transcribed Text: {transcript}")
    print(f"Word Count: {analysis['word_count']}")
    print(f"Filler Count: {analysis['filler_count']}")
    print(f"Pause Count: {analysis['pause_count']}")
    print(f"Fluency Percentage: {analysis['fluency_percentage']:.2f}%")
    print(f"Speech Rate (words per minute): {calculate_speech_rate(audio_duration, analysis['word_count']):.2f}")
    print(f"Audio Duration: {audio_duration:.2f} seconds")

def main():
    while True:
        print("Welcome to the Speech Fluency Assessment Tool!")
        
        # Initialize recognizer and microphone
        recognizer = sr.Recognizer()
        microphone = sr.Microphone()
        
        # Record audio from microphone
        print("Recording...")
        with microphone as source:
            recognizer.adjust_for_ambient_noise(source)
            start_time = time.time()
            audio = recognizer.listen(source, timeout=10)
            end_time = time.time()
        print("Recording finished.")
        
        # Get the duration of the audio recording
        audio_duration = end_time - start_time
        
        # Transcribe speech from recorded audio
        try:
            transcript = recognizer.recognize_google(audio)
        except sr.UnknownValueError:
            print("Sorry, I could not understand the audio.")
            continue
        except sr.RequestError as e:
            print(f"Could not request results from Google Speech Recognition service; {e}")
            continue
        
        # Analyze fluency of transcribed speech
        analysis = assess_fluency(transcript)
        print_analysis(analysis, transcript, audio_duration)
        
        # Ask the user if they want to perform another recording
        choice = input("Do you want to record again? (yes/no): ")
        if choice.lower() != 'yes':
            break  # Exit the loop if the user doesn't want to record again

    

if __name__ == "__main__":
    main()
